﻿using UnityEngine;
using System.Collections;

public enum TypeAudio
{
    SoundMove,
    SoundRotate,
    SoundScore,
    SoundClick,
    SoundLose,
    SoundBG,
    SoundStop,
    SoundDown,
    SoundWaterDrop,
}
