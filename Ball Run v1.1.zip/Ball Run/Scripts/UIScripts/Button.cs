﻿using UnityEngine;
using System.Collections;

public class Button : OnClickButton {

	public override void ClickedButton ()
	{
		//MainButton.Main.OnButtonClick(number);
	}
}
